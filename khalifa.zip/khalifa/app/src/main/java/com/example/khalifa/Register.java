package com.example.khalifa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthEmailException;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity {

    private TextView mTextViewLogin;
    private EditText mEditTextEmail,mEditTextPass,mEditTextCnfPass;
    private FirebaseAuth mAuth;
    private Button mBtnRegister;
    private ProgressBar pb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mTextViewLogin = (TextView) findViewById(R.id.textview_login);

        mTextViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(Register.this,MainActivity.class);
                startActivity(LoginIntent);
            }
        });

        mEditTextEmail = (EditText) findViewById(R.id.edittext_email);
        mEditTextPass = (EditText) findViewById(R.id.edittext_password);
        mEditTextCnfPass = (EditText) findViewById(R.id.edittext_cnf_password);
        mBtnRegister = (Button) findViewById(R.id.button_register);
        pb = (ProgressBar) findViewById(R.id.progressBar2);
        mAuth = FirebaseAuth.getInstance();

        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    public void login(){

        if(mEditTextEmail.getText().toString().trim().isEmpty()){
            mEditTextEmail.setError("Email is required !");
            return;
        }
        if(mEditTextPass.getText().toString().trim().isEmpty() || mEditTextPass.toString().length() < 6){
            mEditTextPass.setError("Password is too short");
            return;
        }
        if(mEditTextCnfPass.getText().toString().trim().isEmpty() || mEditTextCnfPass.equals(mEditTextPass)){
            mEditTextCnfPass.setError("didn't match to the password");
            return;
        }
        pb.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(mEditTextEmail.getText().toString(),mEditTextPass.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(Task<AuthResult> task) {
                        pb.setVisibility(View.GONE);
                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(),"User succefully registred",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),Quiz.class);
                            startActivity(intent);

                        } else
                        {
                            Log.d("err","mabech");
                            if(task.getException() instanceof FirebaseAuthEmailException){
                                Toast.makeText(getApplicationContext(),"Email already registred",Toast.LENGTH_SHORT).show();
                            }
                            Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }
}
